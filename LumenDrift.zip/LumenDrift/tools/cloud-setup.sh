#!/usr/bin/env bash
set -euo pipefail
# Uses the existing isolated /workspace checkout. Do not create a Git worktree.
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
tools_dir=/workspace/toolchains
mkdir -p "$tools_dir" /tmp/lumen-setup
if [[ ! -x "$tools_dir/jdk-21.0.12.1/bin/javac" ]]; then
    curl -fLsS https://download.oracle.com/java/21/archive/jdk-21.0.12.1_linux-x64_bin.tar.gz -o /tmp/lumen-setup/jdk.tar.gz
    curl -fLsS https://download.oracle.com/java/21/archive/jdk-21.0.12.1_linux-x64_bin.tar.gz.sha256 -o /tmp/lumen-setup/jdk.sha256
    python3 - <<'PY'
import hashlib
assert hashlib.sha256(open('/tmp/lumen-setup/jdk.tar.gz','rb').read()).hexdigest() == open('/tmp/lumen-setup/jdk.sha256').read().strip().split()[0]
PY
    tar -xzf /tmp/lumen-setup/jdk.tar.gz -C "$tools_dir"
    if [[ ! -x "$tools_dir/jdk-21.0.12.1/bin/javac" ]]; then
        echo 'The upstream JDK version changed; update cloud-env.sh to the verified installed version.' >&2
        exit 1
    fi
fi
source "$project_dir/tools/cloud-env.sh"
# Use the cloud's managed CA roots for SDK Manager as well as Gradle.
# TLS and package verification remain enabled.
if [[ -r /etc/ssl/certs/java/cacerts ]]; then
    export SDKMANAGER_OPTS="${SDKMANAGER_OPTS:-} -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts"
fi
mkdir -p "$ANDROID_HOME" "$ANDROID_USER_HOME" "$GRADLE_USER_HOME" "$XDG_RUNTIME_DIR"
if [[ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]]; then
    curl -fLsS https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip -o /tmp/lumen-setup/android.zip
    curl -fLsS https://dl.google.com/android/repository/repository2-1.xml -o /tmp/lumen-setup/repository.xml
    python3 - <<'PY'
import hashlib, xml.etree.ElementTree as E
root=E.parse('/tmp/lumen-setup/repository.xml').getroot()
expected=[c.findtext('checksum') for a in root.iter('archive') for c in a.findall('complete') if c.findtext('url')=='commandlinetools-linux-13114758_latest.zip']
assert len(expected)==1 and hashlib.sha1(open('/tmp/lumen-setup/android.zip','rb').read()).hexdigest()==expected[0]
PY
    unzip -q /tmp/lumen-setup/android.zip -d /tmp/lumen-setup/sdk
    mkdir -p "$ANDROID_HOME/cmdline-tools/latest"
    cp -a /tmp/lumen-setup/sdk/cmdline-tools/. "$ANDROID_HOME/cmdline-tools/latest/"
fi
# Cloud-only Java proxy/trust configuration, stored outside the distributable project.
python3 - <<'PY'
import os, pathlib, urllib.parse
p=pathlib.Path(os.environ['GRADLE_USER_HOME'])/'gradle.properties'
s=p.read_text() if p.exists() else ''
proxy=urllib.parse.urlparse(os.environ.get('HTTPS_PROXY',''))
props={}
if proxy.hostname:
    if proxy.username or proxy.password:
        raise SystemExit('Authenticated proxy requires secure external configuration; do not save credentials.')
    for scheme in ('http','https'):
        props[f'systemProp.{scheme}.proxyHost']=proxy.hostname
        props[f'systemProp.{scheme}.proxyPort']=str(proxy.port or 8080)
    props['systemProp.http.nonProxyHosts']='localhost|127.*|[::1]'
trust=pathlib.Path('/etc/ssl/certs/java/cacerts')
if trust.exists(): props['systemProp.javax.net.ssl.trustStore']=str(trust)
lines=[line for line in s.splitlines() if line.split('=',1)[0] not in props]
lines += [f'{key}={value}' for key,value in props.items()]
p.write_text('\n'.join(lines)+'\n')
PY
# License acceptance for Android SDK development tools.
set +o pipefail
yes | sdkmanager --licenses >/tmp/lumen-setup/licenses.log
license_status=${PIPESTATUS[1]}
set -o pipefail
[[ "$license_status" == 0 ]]
sdkmanager 'platform-tools' 'platforms;android-36' 'build-tools;35.0.0'
if [[ "${INSTALL_EMULATOR:-0}" == 1 ]]; then
    sdkmanager 'emulator' 'system-images;android-29;default;x86_64'
    if [[ ! -f "$ANDROID_AVD_HOME/LumenTest29.avd/config.ini" ]]; then
        mkdir -p "$ANDROID_AVD_HOME"
        set +o pipefail
        printf 'no\n' | avdmanager create avd -n LumenTest29 -k 'system-images;android-29;default;x86_64' -d pixel_2
        avd_status=${PIPESTATUS[1]}
        set -o pipefail
        [[ "$avd_status" == 0 ]]
        python3 - <<'CONFIG'
import os,pathlib
p=pathlib.Path(os.environ['ANDROID_AVD_HOME'])/'LumenTest29.avd/config.ini'
values={'hw.lcd.width':'432','hw.lcd.height':'960','hw.lcd.density':'168','showDeviceFrame':'no','hw.keyboard':'yes'}
s=[line for line in p.read_text().splitlines() if line.split('=',1)[0].strip() not in values]
p.write_text('\n'.join(s+[f'{k}={v}' for k,v in values.items()])+'\n')
CONFIG
    fi
fi
# Local configuration only; preserve a developer's existing SDK selection.
if [[ ! -f "$project_dir/local.properties" ]]; then
    printf 'sdk.dir=%s\n' "$ANDROID_HOME" > "$project_dir/local.properties"
fi
cd "$project_dir"
if [[ "${SKIP_BUILD:-0}" != 1 ]]; then
    ./gradlew :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
fi
