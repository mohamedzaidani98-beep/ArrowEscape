#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./gradlew :app:assembleDebug :app:testDebugUnitTest :app:lintDebug :app:assembleDebugAndroidTest :app:bundleRelease
if [[ "${RUN_DEVICE_TESTS:-0}" == 1 ]]; then
    ./gradlew :app:connectedDebugAndroidTest
fi
