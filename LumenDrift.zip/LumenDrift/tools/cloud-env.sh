#!/usr/bin/env bash
# Source this file in the prepared Codex machine. No credentials are stored here.
export JAVA_HOME=/workspace/toolchains/jdk-21.0.12.1
export ANDROID_HOME=/workspace/toolchains/android
export ANDROID_USER_HOME=/workspace/toolchains/android-user
export ANDROID_EMULATOR_HOME=/workspace/toolchains/android-user
export ANDROID_AVD_HOME=/workspace/toolchains/avd
export XDG_RUNTIME_DIR=/workspace/toolchains/runtime
export GRADLE_USER_HOME=/workspace/toolchains/gradle-home
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/emulator:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
