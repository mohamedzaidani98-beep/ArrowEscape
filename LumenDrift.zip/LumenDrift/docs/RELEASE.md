# Commercial release handoff

This project is a runnable development candidate, not an already approved Play listing.

1. Clear the final brand and application ID. `com.lumendrift.game` is a proposed identifier,
   not an assertion of domain ownership. Confirm original art and third-party license notices.
2. Supply the missing OWASP requirements, complete the security mapping and any resulting
   fixes, and review dependencies against current advisories.
3. Establish the publisher's audience classification. This default integration does not
   assert child-directed treatment. If targeting children, implement the applicable Families
   policy, appropriate ad/consent request flags, and approved SDK configurations before use.
4. Create an AdMob app and consent messages, including regional privacy options. Replace the
   sample app and banner IDs with publisher-owned IDs only after consent testing. Keep test
   devices configured while testing production units. Never click live advertisements.
5. Publish a real HTTPS privacy policy with publisher identity and contact details. Update
   the in-app development privacy notice to reference it and accurately describe final SDKs.
   Complete Play Data Safety, advertising-ID, ads declaration, age/content ratings, and consent
   disclosures from the actual release behavior. Include Google SDK collection/sharing.
6. Configure Play App Signing and a private upload key. Do not commit keys/passwords. Sign
   `bundleRelease` via a secure CI or Android Studio signing flow. Increment versionCode on updates.
7. Test the signed/minified release on physical phones and tablets, Android 7–16, rotation,
   larger text, TalkBack, background/process death, offline launch, consent grant/refusal,
   privacy changes, no-fill/error ads, and different display cutouts. API 36 is targeted;
   recheck the current Play target-API policy at the time of submission.
8. Supply original store screenshots, feature graphic, contact/support details, content rating,
   and testing-track feedback. Use internal/closed testing before production.

The included consent flow uses official UMP APIs. Google's sample app ID does not establish
publisher-specific form delivery. Consent/ad end-to-end verification requires an AdMob
account with configured messages and test-device/geography settings; it remains a release gate.

There are no purchases, gambling, external downloads, push notifications, or account login.
No commercial readiness claim replaces Play review, policy verification, or device QA.
