# Delivery validation

All results below describe this prepared machine and the delivered source/artifacts. They do
not claim that an environment snapshot was published or restored in a separate task.

## Passed checks

| Check | Result |
| --- | --- |
| Debug APK (`assembleDebug`) | Passed |
| Minified, resource-shrunk release bundle (`bundleRelease`) | Passed; unsigned |
| JVM suite (`testDebugUnitTest`) | **9 passed, 0 failed, 0 skipped** |
| AndroidJUnitRunner on API 29 x86_64 emulator | **3 passed, 0 failed** |
| Debug lint and release vital lint | Passed; debug report has 7 style warnings, no errors |
| Final `tools/verify.sh` build pipeline | Passed |
| Full `INSTALL_EMULATOR=1 tools/cloud-setup.sh` refresh | Passed |
| APK 16 KB ZIP alignment | Passed (`zipalign -c -P 16 4`) |
| Native ELF LOAD alignment | All four shipped ABIs have >= 16 KB alignment |
| Native startup smoke | Activity start returned `Status: ok`; Home action opened puzzle 001 with 5 remaining |
| Reference checkout | `git status --short` remained empty |

The five pure Kotlin rule tests include collision fixtures for every cardinal direction,
unknown/already removed IDs, star bounds, invalid levels, deterministic generation, witness
solutions, and legal-move completion over **2,400 seeded boards**. Two Robolectric persistence
tests cover restoration, preferences, corrupt JSON, daily/campaign separation, best-score
retention, and deletion. Two Robolectric Compose tests exercise touch on a board lantern and
the settings/large-controls/full-level/next-level flow using native graphics.

The three real Android device tests complete and advance a puzzle, check daily and campaign
progress, and check moves/hints/preferences through recreation and fresh model restoration.
They ran with Wi-Fi/data disabled. The underlying Android runner reported `OK (3 tests)`;
its individual start/completion records are retained in `test-results/device-instrumentation.txt`.
The Gradle `connectedDebugAndroidTest` entry point is supplied for normal developer use; the
recorded device run used `adb shell am instrument -w -r` directly.

Final JVM reports are under `test-results/TEST-*.xml`. Build, setup, lint, and final pipeline
records are retained alongside them. A supported adaptive-banner sizing method emits a
Google SDK deprecation warning; no checks or assertions were disabled to obtain success.

## Difficulty sanity check

A separate diagnostic examined the exact 120 campaign seeds. 117 boards begin with at least
one blocked trail; the introductory boards include simple free-launch warmups. Chapter 1
averages 7.3 trails and 2.5 release waves; chapter 6 averages 12.1 trails and 3.2 waves. Individual
levels vary in difficulty. The deepest observed dependency chain required six release waves.
Targets increase with level, but dense geometry can yield fewer trails than the requested
count. This is a relaxed, finite journey rather than a claim of strictly monotonic difficulty.

## Runtime and screenshots

The validated toolchain is JDK 21, Gradle 8.13, AGP 8.13.2, Kotlin/Compose compiler 2.3.20,
Android compile/target 36, build tools 35.0.0, and minimum API 24. The emulator ran API 29
without KVM, with one virtual CPU and SwiftShader. Multicore software-emulator attempts
stalled. Android System UI showed an ANR under emulation load after the tests; it was
recovered, followed by successful Activity startup and a visible puzzle smoke check. This
was a platform dialog, not an application crash. Physical-device and other API-level QA
remain release work; API 36 targeting is not a claim of API 36 device testing.

These first two images are actual screenshots of the installed app on Android API 29:

![Installed Android home screen](screenshots/device-home.png)

![Installed Android puzzle screen](screenshots/device-puzzle.png)

Additional `jvm-*.png` images are explicitly **Robolectric native-Canvas renders**, captured
from the actual Compose decor view. They are not physical-device screenshots. PixelCopy
requires a real display, so the JVM renderer uses the supported software Canvas path.

## Security and publication limits

The merged release manifest disables backup and cleartext networking and includes Android
12+ cloud/device-transfer exclusions. Its unprotected exported component is the launcher.
SDK-exported WorkManager/ProfileInstaller components require BIND_JOB_SERVICE or DUMP.
Dependencies add AD_ID, AdServices advertising ID/attribution/topics, WAKE_LOCK, and
FOREGROUND_SERVICE permissions in addition to network permissions; these need accurate
publisher disclosures. There is no production signing key in the project, and the AAB has
no JAR signature. Only Google's official sample AdMob application/banner IDs are included.

Offline gameplay and consent-service failure handling were verified. **Live UMP form
presentation, regional consent behavior, privacy revocation with actual ad serving, and
test-banner delivery were not verified**: those require the owner's publisher app and
configured consent messages. Unknown consent does not authorize an ad request in this app.

The separately mentioned OWASP requirements were not supplied. Implemented controls and
remaining review areas are documented in `SECURITY.md`; no certification against an unseen
checklist is claimed. See `RELEASE.md` for privacy-policy, audience, AdMob/UMP, signing,
physical-device QA, and Google Play submission requirements. This is a tested development
and release candidate, not a published or Play-approved application.

Reusable `install_script` and `start_skill` fields were saved in the environment draft.
Saving did not publish or apply a new snapshot. Review/save that draft in environment
settings and publish when ready. Restoration in a fresh task has not been independently tested.
