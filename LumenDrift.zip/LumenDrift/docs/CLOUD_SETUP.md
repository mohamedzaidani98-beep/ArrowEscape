# Reusable cloud workflow

Use the existing isolated workspace; do not create a Git worktree. The new project is at
`/workspace/LumenDrift`. `/workspace/ArrowEscape` remains the unchanged reference checkout.

## Prepare or refresh

```sh
INSTALL_EMULATOR=1 bash /workspace/LumenDrift/tools/cloud-setup.sh
source /workspace/LumenDrift/tools/cloud-env.sh
cd /workspace/LumenDrift
./tools/verify.sh
```

The setup helper installs/activates a verified JDK, Android SDK, and optional API 29 emulator,
configures the cloud Java proxy and managed CA trust outside the project, preserves an existing
`local.properties`, and runs build/unit/lint checks. It never disables TLS or artifact checks.
`SKIP_BUILD=1` checks installation only; that flag does not establish app readiness.
The Android SDK licenses are accepted for development by the setup helper.

Retain installed tools, dependency caches, and AVD disk files in the environment snapshot.
Emulator/ADB/Gradle processes must not be assumed to survive publication or reconnection.
The hard-coded paths in `cloud-env.sh` are only for this prepared cloud machine; Android Studio
users should use their own SDK and JDK configuration as described in the root README.

## Start the native app

```sh
source /workspace/LumenDrift/tools/cloud-env.sh
cd /workspace/LumenDrift
adb devices
# If no ready device exists, start the prepared AVD in a background terminal:
emulator -avd LumenTest29 -no-window -no-audio -no-boot-anim \
  -gpu swiftshader -feature -Vulkan -accel off -cores 1 -memory 2048 \
  -no-snapshot -no-metrics -camera-back none -camera-front none
```

Use one emulator instance per AVD. Wait until `adb shell getprop sys.boot_completed` returns
`1`; a device listed as `offline` or an open process is not readiness. In this machine there is
no `/dev/kvm`. A single virtual CPU was necessary for useful software-emulator startup;
multicore API 29/35 attempts stalled. Cold boot can take several minutes. System UI can show
an ANR under heavy emulation load; distinguish a platform dialog from an app crash.
Do not disable application error reporting or mark stalled tests as passed.

Once Android is ready:

```sh
adb shell input keyevent KEYCODE_WAKEUP
adb shell wm dismiss-keyguard
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell am start -W -n com.lumendrift.game/.MainActivity
```

Check that Lumen Drift is visible and a puzzle can be opened, not merely that an Activity PID
exists. The tested device runner installs the AndroidTest APK and executes:

```sh
adb install -r -t app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
adb shell am instrument -w -r \
  com.lumendrift.game.test/androidx.test.runner.AndroidJUnitRunner
```

Require the runner's `OK (3 tests)` result, with all three named tests completing. The equivalent
standard Gradle entry point is `./gradlew :app:connectedDebugAndroidTest`, also available through
`RUN_DEVICE_TESTS=1 ./tools/verify.sh`. Do not infer success from `am instrument` exit status alone.
The device tests were run with Wi-Fi/data disabled to validate offline play and avoid live ads.

Only public Google sample ad IDs are present. Publisher-configured UMP forms, regional consent
behavior, privacy revocation with actual ad delivery, and live test-banner serving require the
owner's AdMob/consent configuration and remain separate release checks.
