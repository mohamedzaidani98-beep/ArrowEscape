# Android security and privacy review

The separately mentioned OWASP requirements were not present in the task material at the
time of implementation. This document records implemented controls; it is not certification
against an unseen checklist or a complete MASVS audit.

## Implemented controls

- No application backend, account, password, API secret, payment, or remote command channel.
- No application-owned WebView, JavaScript bridge, dynamic code loading, external storage, or downloaded assets.
  Google UMP may present its own web-based consent form.
- Only the launcher activity is exported; no deep links, services, or content providers are
  defined by application code. Review merged dependency manifests as part of release review.
- Application cleartext traffic is disabled. SDK networking uses platform TLS; no custom
  permissive trust manager, hostname bypass, or application certificate override exists.
- Progress/settings use MODE_PRIVATE app storage. No sensitive player data is stored.
  Restored local JSON is length-bounded, integer values are constrained, and removed IDs are
  filtered against the regenerated board. Malformed saved sessions fail closed to no session.
- Backup and device transfer are excluded using both legacy flags and Android 12+ extraction rules. No application logging of identifiers, consent payloads, or player data.
- No analytics SDK or developer telemetry. Mobile Ads and UMP are the only ad/privacy SDKs.
- Ad requests and the explicit `MobileAds.initialize` call are gated on UMP `canRequestAds()`.
  The delay-app-measurement metadata flag is enabled. Android still creates SDK manifest
  bootstrap providers at process startup; consent does not remove those providers. Consent update
  failures leave offline gameplay available. Privacy options are available in Settings when
  required by UMP, with a retry flow when unavailable. Consent values are never fabricated.
- Banners use Google's official test identifiers and only appear on home/journey screens,
  away from puzzle gestures. AdViews pause/resume with lifecycle and are destroyed on disposal.
- Release builds enable R8 and resource shrinking and do not configure a debug signing key.
  Production signing material belongs outside source control and must be supplied by the owner.
- Dependencies and build tools have explicit versions; the Gradle distribution checksum is
  verified. Android tools are retrieved with TLS and repository metadata verification.

## Remaining verification before release

Map the supplied OWASP list to code and evidence when provided. Perform dependency advisory
review, merged-manifest and exported-component review, dynamic network inspection, privacy
form testing with configured AdMob messages in relevant jurisdictions, and release build
inspection on supported API levels. Unit tests do not prove consent service behavior.

Google SDKs can add permissions/components, including advertising-related declarations.
The publisher must inspect the final merged manifest and complete Google Play Data Safety
and advertising-ID disclosures using actual SDK behavior and configuration. Do not claim
this app is data-free merely because puzzle progress stays local. Public privacy policy,
controller identity/contact, audience classification, and consent messaging are owner inputs.

Encryption of ordinary game scores is not treated as a security boundary. Local progress
can be altered on rooted devices; no rewards, purchases, or competitive ranking depend on it.
