# Reference behavior study and independent design

Reference: https://github.com/sidhant947/ArrowEscape
Inspected source at HEAD `790c562e1ca0d8d584511ae54cb613b5bfb37786`, also present in the
user-selected `mohamedzaidani98-beep/ArrowEscape` checkout. Study was limited to available
source and descriptive text. REA and binary reverse engineering were unnecessary.

## Observations

The reference represents each arrow as a cardinal heading and a connected grid path.
A tap launches a path along the tip's heading. Other paths obstruct its route. Some levels
include neutral dots and directional redirectors consumed on exit. A solver checks exits
and handles redirector-dependent choices. The generator uses seeded procedural shapes;
board sizes and special boss/god tiers increase with level. Regular boards grow from about
10 to 32 cells per side, with distinct five- and ten-level special cycles.

Classic play starts with three lives and penalizes blocked taps. Other modes include relaxed
and timed variants. The UI includes assist settings, theme selection, and level navigation.
Controls center on tapping arrow segments, with optional nearby-tap assistance.
An InteractiveViewer supports panning and pinch scaling from 0.8× to 4× for dense boards. Paths animate
on release and shake when blocked. Progress is stored locally.

The technical stack is Flutter with Flame for game rendering, Riverpod for state bindings,
and Hive for local persistence. Separate modules define models, level generation, route
solving, repositories, screens, and game components. The project is GPL v3.

## Independent implementation

Lumen Drift takes only the general abstract puzzle idea of clearing directional trails.
Its Kotlin code was written independently, without translating or copying Dart routines.
No source, graphic, text, font, sound, shape mask, exact level, or dependency configuration
was imported from the reference. No GPL source is shipped or linked into the new app.

The new game deliberately has its own rules: no redirectors, consumable dots, boss tiers,
lives, combo timing, or theme-unlock codes. It uses 5–7-cell boards, an original six-chapter
journey, forgiving mistakes, free route hints, a star score, a daily seed, and a lantern-garden
visual identity. Smaller boards and an optional text list support readable mobile play.

A separate constructive generator places a trail only when its forward ray is clear of
already placed trails. Therefore reverse insertion order proves a solution. Since removing
a trail cannot create a blocker, every legal move preserves at least one solution. Tests
exercise that invariant with different legal removal orders and many seeds.

Difficulty increases through board size, trail count targets, and longer paths. Generation
may produce fewer trails than the target when geometric space is exhausted. The 120 puzzles
are deterministic for generator revision 1. Changing the generator requires a persistence
migration so saved removed IDs continue to describe the same puzzle.

Original branding has not undergone a trademark search. Commercial naming clearance and
legal review are publisher responsibilities; this study is a provenance record, not a legal
opinion or claim of exclusive rights over an abstract game mechanic.
