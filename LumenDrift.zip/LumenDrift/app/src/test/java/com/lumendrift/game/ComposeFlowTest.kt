package com.lumendrift.game

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import android.graphics.Bitmap
import android.graphics.Canvas
import org.junit.Assert.assertTrue
import java.io.File
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29], qualifiers = "w411dp-h914dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class ComposeFlowTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test fun playerCanEnableLargeControlsClearAPuzzleAndAdvance() {
        compose.activityRule.scenario.onActivity { activity ->
            ViewModelProvider(activity)[GameModel::class.java].updateReducedMotion(true)
        }
        screenshot("home")
        compose.onNodeWithText("Settings").performClick()
        compose.onNodeWithContentDescription("List controls").performClick()
        compose.activityRule.scenario.onActivity { activity ->
            val model = ViewModelProvider(activity)[GameModel::class.java]
            model.updateListControls(true)
            model.updateReducedMotion(true)
            model.start(1)
        }
        screenshot("puzzle")
        PuzzleFactory.create(1).lanterns.reversed().forEach { lantern ->
            compose.onNodeWithText("${lantern.id+1} · row ${lantern.cells.first().y+1}, column ${lantern.cells.first().x+1} · ${lantern.heading.label}")
                .performScrollTo().performClick()
        }
        compose.onNodeWithText("A clear sky.").assertExists()
        screenshot("complete")
        compose.onNodeWithText("Next puzzle  →").performScrollTo().performClick()
        compose.onNodeWithText("PUZZLE 002").assertExists()
    }
    @Test fun playerCanReleaseALanternByTappingTheBoard() {
        val puzzle = PuzzleFactory.create(1)
        val lantern = puzzle.lanterns.last()
        compose.activityRule.scenario.onActivity { activity ->
            val model = ViewModelProvider(activity)[GameModel::class.java]
            model.updateListControls(false)
            model.updateReducedMotion(true)
            model.start(1)
        }
        val head = lantern.cells.first()
        compose.onNodeWithContentDescription("Lantern ${lantern.id+1}, ${lantern.heading.label}, row ${head.y+1}, column ${head.x+1}")
            .performScrollTo().performTouchInput { click() }
        compose.onNodeWithText("${puzzle.lanterns.size-1} remaining").assertExists()
        compose.activityRule.scenario.onActivity { activity ->
            assertTrue(lantern.id in ViewModelProvider(activity)[GameModel::class.java].session!!.removed)
        }
    }

    private fun screenshot(name: String) {
        val directory = System.getProperty("lumen.screenshot.dir") ?: return
        val file = File(directory, "$name.png")
        file.parentFile!!.mkdirs()
        // PixelCopy needs a real Android display. Render the decor view with Robolectric's
        // native Canvas instead; these artifacts are explicitly labeled as JVM renders.
        compose.runOnIdle {
            val view = compose.activity.window.decorView
            val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap))
            file.outputStream().use { stream ->
                check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream))
            }
        }
    }
}
