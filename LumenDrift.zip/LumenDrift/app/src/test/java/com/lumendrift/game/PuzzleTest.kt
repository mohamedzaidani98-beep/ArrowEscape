package com.lumendrift.game

import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class PuzzleTest {
    @Test fun blockedLaunchNamesTheBlockingTrail() {
        val p = Puzzle(1, 5, listOf(
            Lantern(0, listOf(Cell(1, 1), Cell(0, 1)), Heading.EAST),
            Lantern(1, listOf(Cell(3, 2), Cell(3, 1)), Heading.SOUTH)))
        assertEquals(Launch.Blocked(1), Rules.launch(p, emptySet(), 0))
        assertEquals(Launch.Released(1), Rules.launch(p, emptySet(), 1))
        assertEquals(Launch.Released(0), Rules.launch(p, setOf(1), 0))
        assertEquals(Launch.Ignored, Rules.launch(p, setOf(0), 0))
        assertEquals(Launch.Ignored, Rules.launch(p, emptySet(), 99))
    }
    @Test fun allDirectionsRespectEdgesAndInterveningBodies() {
        Heading.entries.forEach { dir ->
            val center = Cell(2,2)
            val p = Puzzle(1, 5, listOf(Lantern(0, listOf(center), dir),
                Lantern(1, listOf(center + dir), dir)))
            assertTrue(Rules.launch(p, emptySet(), 0) is Launch.Blocked)
            assertTrue(Rules.launch(p, setOf(1), 0) is Launch.Released)
        }
    }
    @Test fun campaignAndDailySeedsHaveValidGeometryAndAlwaysSolve() {
        val choice = Random(42)
        for (seed in 0L until 20L) for (level in 1..120) {
            val p = PuzzleFactory.create(level, seed * 100003 + level)
            val all = p.lanterns.flatMap { it.cells }
            assertEquals(all.size, all.toSet().size)
            assertTrue(all.all(p::inside))
            assertTrue(p.lanterns.size >= 3)
            p.lanterns.forEach { lantern ->
                assertTrue(lantern.cells.size >= 2)
                lantern.cells.zipWithNext().forEach { (a,b) ->
                    assertEquals(1, kotlin.math.abs(a.x-b.x) + kotlin.math.abs(a.y-b.y))
                }
                assertEquals(lantern.cells.first() + lantern.heading.opposite(), lantern.cells[1])
            }
            val removed = mutableSetOf<Int>()
            while (removed.size < p.lanterns.size) {
                val available = Rules.available(p, removed)
                assertFalse("Deadlock at level $level seed $seed", available.isEmpty())
                removed += available[choice.nextInt(available.size)]
            }
        }
    }
    @Test fun reverseConstructionOrderIsASolutionAndGenerationIsStable() {
        for (level in 1..120) {
            val p = PuzzleFactory.create(level)
            assertEquals(p, PuzzleFactory.create(level))
            val removed = mutableSetOf<Int>()
            p.lanterns.reversed().forEach {
                assertEquals(Launch.Released(it.id), Rules.launch(p, removed, it.id))
                removed += it.id
            }
        }
        assertNotEquals(PuzzleFactory.create(80, 17), PuzzleFactory.create(80, 18))
    }
    @Test fun invalidLevelsRejectedAndStarsAreBounded() {
        listOf(0, -1, 121, Int.MAX_VALUE).forEach {
            assertThrows(IllegalArgumentException::class.java) { PuzzleFactory.create(it) }
        }
        assertEquals(3, Rules.stars(0,0))
        assertEquals(2, Rules.stars(0,1))
        assertEquals(1, Rules.stars(20,20))
    }
}
