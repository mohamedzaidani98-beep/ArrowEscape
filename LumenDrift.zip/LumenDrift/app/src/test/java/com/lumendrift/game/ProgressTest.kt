package com.lumendrift.game

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29])
class ProgressTest {
    @Test fun sessionRestoresMovesPreferencesAndRejectsMalformedData() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val model = GameModel(app)
        model.eraseProgress()
        model.start(1)
        val id = Rules.available(model.session!!.puzzle, emptySet()).first()
        assertTrue(model.tap(id))
        model.hint()
        model.updateReducedMotion(true)
        val restored = GameModel(app)
        assertEquals(setOf(id), restored.session!!.removed)
        assertEquals(1, restored.session!!.hints)
        assertTrue(restored.reducedMotion)
        restored.restart()
        assertTrue(restored.session!!.removed.isEmpty())
        app.getSharedPreferences("lumen_local_v1", 0).edit().putString("session", "{broken json").commit()
        assertNull(GameModel(app).session)
    }

    @Test fun dailyHasSeparateProgressAndReplaysKeepTheBestStars() {
        val model = GameModel(ApplicationProvider.getApplicationContext())
        model.eraseProgress()
        model.start(45, daily = true)
        model.session!!.puzzle.lanterns.reversed().forEach { model.tap(it.id) }
        assertTrue(model.dailyDone())
        assertEquals(1, model.unlocked)
        model.start(1)
        model.session!!.puzzle.lanterns.reversed().forEach { model.tap(it.id) }
        assertEquals(3, model.stars[1])
        assertEquals(2, model.unlocked)
        model.start(1)
        model.hint()
        model.hint()
        model.session!!.puzzle.lanterns.reversed().forEach { model.tap(it.id) }
        assertEquals(3, model.stars[1])
        model.eraseProgress()
        assertEquals(1, model.unlocked)
        assertEquals(0, model.stars[1])
        assertFalse(model.dailyDone())
    }
}
