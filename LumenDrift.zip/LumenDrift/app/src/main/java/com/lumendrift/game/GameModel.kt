package com.lumendrift.game

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Page { HOME, ATLAS, PLAY, SETTINGS }
data class Session(
    val puzzle: Puzzle,
    val dailyDate: String? = null,
    val removed: Set<Int> = emptySet(),
    val mistakes: Int = 0,
    val hints: Int = 0,
    val hint: Int? = null,
    val blocked: Int? = null,
    val message: String = "Follow the tip. Find a clear way out.",
    val event: Int = 0
) {
    val complete get() = removed.size == puzzle.lanterns.size
    val remaining get() = puzzle.lanterns.size - removed.size
}
class GameModel(application: Application) : AndroidViewModel(application) {
    private val preferences = application.getSharedPreferences("lumen_local_v1", 0)
    var page by mutableStateOf(Page.HOME); private set
    var unlocked by mutableIntStateOf(preferences.getInt("unlocked", 1).coerceIn(1, 120)); private set
    var haptics by mutableStateOf(preferences.getBoolean("haptics", true)); private set
    var reducedMotion by mutableStateOf(preferences.getBoolean("reducedMotion", false)); private set
    var listControls by mutableStateOf(preferences.getBoolean("listControls", false)); private set
    var stars by mutableStateOf((1..120).associateWith { preferences.getInt("stars_$it",0).coerceIn(0,3) }); private set
    var session by mutableStateOf(restore()); private set
    fun navigate(destination: Page) { page = destination }
    fun start(level: Int, daily: Boolean = false) {
        val safe = level.coerceIn(1, if (daily) 120 else unlocked)
        val date = if (daily) today() else null
        val puzzle = PuzzleFactory.create(safe, date?.toLong() ?: (safe.toLong() * 7919L))
        session = Session(puzzle, date)
        saveSession(); page = Page.PLAY
    }
    fun continueGame() {
        if (session == null || session?.complete == true) start(unlocked) else page = Page.PLAY
    }
    fun restart() {
        session?.let { session = Session(it.puzzle, it.dailyDate); saveSession() }
    }
    fun tap(id: Int): Boolean {
        val current = session ?: return false
        if (current.complete) return false
        val next = when (val result = Rules.launch(current.puzzle, current.removed, id)) {
            is Launch.Released -> current.copy(removed = current.removed + id, hint = null, blocked = null,
                message = "A little more room to breathe.", event = current.event + 1)
            is Launch.Blocked -> current.copy(mistakes = current.mistakes + 1, blocked = id, hint = null,
                message = "The route is occupied. Release another lantern first.", event = current.event + 1)
            Launch.Ignored -> return false
        }
        session = next
        if (next.complete) {
            if (next.dailyDate == null) {
                val number = next.puzzle.level
                val rating = maxOf(stars[number] ?: 0, Rules.stars(next.mistakes, next.hints))
                stars = stars + (number to rating)
                unlocked = maxOf(unlocked, (number + 1).coerceAtMost(120))
                preferences.edit().putInt("stars_$number", rating).putInt("unlocked", unlocked).apply()
            } else {
                preferences.edit().putString("dailyDone", next.dailyDate).apply()
            }
        }
        saveSession()
        return next.mistakes == current.mistakes
    }
    fun hint() {
        val current = session ?: return
        if (current.complete) return
        val id = Rules.available(current.puzzle, current.removed).firstOrNull() ?: return
        session = current.copy(hint = id, blocked = null, hints = current.hints + 1,
            message = "The glowing lantern has a clear route.", event = current.event + 1)
        saveSession()
    }
    fun updateHaptics(value: Boolean) { haptics = value; preferences.edit().putBoolean("haptics", value).apply() }
    fun updateReducedMotion(value: Boolean) { reducedMotion = value; preferences.edit().putBoolean("reducedMotion", value).apply() }
    fun updateListControls(value: Boolean) { listControls = value; preferences.edit().putBoolean("listControls", value).apply() }
    fun dailyDone() = preferences.getString("dailyDone", "") == today()
    fun eraseProgress() {
        preferences.edit().clear().apply()
        stars = (1..120).associateWith { 0 }; unlocked = 1; session = null
        haptics = true; reducedMotion = false; listControls = false; page = Page.HOME
    }
    private fun saveSession() {
        val s = session ?: return
        val json = JSONObject().put("level",s.puzzle.level).put("date",s.dailyDate ?: "")
            .put("removed",JSONArray(s.removed.toList())).put("mistakes",s.mistakes).put("hints",s.hints)
        preferences.edit().putString("session",json.toString()).apply()
    }
    private fun restore(): Session? = runCatching {
        val raw = preferences.getString("session", null) ?: return null
        if (raw.length > 16000) return null
        val j = JSONObject(raw)
        val level = j.getInt("level").coerceIn(1,120)
        val date = j.optString("date").takeIf { it.matches(Regex("[0-9]{8}")) }
        val p = PuzzleFactory.create(level, date?.toLong() ?: (level.toLong() * 7919L))
        val ids = j.getJSONArray("removed")
        val valid = p.lanterns.map { it.id }.toSet()
        val removed = (0 until ids.length().coerceAtMost(100)).map { ids.optInt(it,-1) }.filter { it in valid }.toSet()
        Session(p,date,removed,j.optInt("mistakes").coerceIn(0,9999),j.optInt("hints").coerceIn(0,9999))
    }.getOrNull()
    companion object {
        fun today(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    }
}
