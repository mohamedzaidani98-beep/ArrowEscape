package com.lumendrift.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlin.math.min

val Paper = Color(0xFFF5F1E8)
val Ink = Color(0xFF182E36)
val Muted = Color(0xFF596A6D)
val Sage = Color(0xFF32685A)
val Copper = Color(0xFFAA553A)
val Gold = Color(0xFFE8B77D)
val Line = Color(0xFFDADDD2)
private val TrailColors = listOf(Sage, Copper, Color(0xFF426B87), Color(0xFF76628D))
private val Chapters = listOf("First light", "Tidal garden", "Quiet currents", "Amber passage", "Night orchard", "Open sky")

class MainActivity : ComponentActivity() {
    private val model: GameModel by viewModels()
    private lateinit var privacy: PrivacyAds
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.light(Paper.toArgb(), Ink.toArgb()),
            navigationBarStyle = SystemBarStyle.light(Paper.toArgb(), Ink.toArgb()))
        privacy = PrivacyAds(this)
        setContent { LumenApp(model, privacy) }
        privacy.requestConsent()
    }
}

@Composable
fun LumenApp(model: GameModel = viewModel(), privacy: PrivacyAds) {
    var guide by remember { mutableStateOf(false) }
    var privacyText by remember { mutableStateOf(false) }
    var reset by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(
        primary = Sage, onPrimary = Color.White, background = Paper, onBackground = Ink,
        surface = Paper, onSurface = Ink, secondary = Copper, outline = Line,
        surfaceContainer = Color(0xFFECEDE2)
    )) {
        BackHandler(enabled = model.page != Page.HOME) { model.navigate(Page.HOME) }
        Surface(Modifier.fillMaxSize(), color = Paper) {
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                Column(Modifier.weight(1f).widthIn(max = 680.dp).fillMaxWidth().align(Alignment.CenterHorizontally)) {
                    when (model.page) {
                        Page.HOME -> Home(model, { guide = true })
                        Page.ATLAS -> Atlas(model)
                        Page.PLAY -> Play(model, { guide = true })
                        Page.SETTINGS -> Settings(model, privacy, { privacyText = true }, { reset = true })
                    }
                }
                // Never place advertisements beside moving puzzle controls.
                if (model.page == Page.HOME || model.page == Page.ATLAS) TestBanner(privacy)
            }
        }
        if (guide) AlertDialog(onDismissRequest = { guide = false }, title = { Text("Let the light through", fontFamily = FontFamily.Serif) },
            text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("1  Find a lantern’s pointed tip. Tap its trail to send it in that direction.")
                Text("2  Its tip needs a clear line to the edge. Another trail in that line blocks the launch.")
                Text("3  Release blocking lanterns first, until the whole sky is clear.")
                Text("There is no timer and no life limit. A blocked tap stays put. Three stars means no blocked taps or hints; one assist costs a star, two or more give one star.")
                Text("Reveal route highlights a safe lantern. Hints are always free. Use List controls in Settings for larger, spoken controls.")
            } }, confirmButton = { TextButton(onClick = { guide = false }) { Text("I’m ready") } })
        if (privacyText) AlertDialog(onDismissRequest = { privacyText = false }, title = { Text("Your quiet corner") },
            text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Lumen Drift saves puzzle progress and preferences only in this app’s private storage. No account, developer analytics, cloud sync, or location permission is used. Delete local data in Settings or uninstall to remove it.")
                Text("This development build uses Google AdMob test advertisements and Google’s User Messaging Platform. These third-party services may process IP addresses, device identifiers, diagnostics, and ad interactions under Google’s privacy policy. Ads are requested only when the consent SDK permits them. Consent choices depend on your region; where required, use Privacy choices to change them.")
                Text("The game works offline. Privacy services and advertisements need a network connection. This in-app notice is a development notice; a public privacy policy and publisher contact must be supplied before release.")
            } }, confirmButton = { TextButton(onClick = { privacyText = false }) { Text("Close") } })
        if (reset) AlertDialog(onDismissRequest = { reset = false }, title = { Text("Start a fresh journey?") },
            text = { Text("This permanently deletes this device’s puzzle progress, stars, and preferences. It does not reset Google’s privacy choices.") },
            confirmButton = { TextButton(onClick = { model.eraseProgress(); reset = false }) { Text("Delete local progress") } },
            dismissButton = { TextButton(onClick = { reset = false }) { Text("Keep my journey") } })
    }
}

@Composable
private fun Header(title: String, back: (() -> Unit)? = null, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) TextButton(onClick = back) { Text("‹  Back", color = Ink) }
        else Text("◈", color = Sage, fontSize = 26.sp, modifier = Modifier.padding(12.dp))
        Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 1.sp)
        if (action != null) TextButton(onClick = onAction) { Text(action, color = Ink) }
    }
}
@Composable
private fun Eyebrow(text: String, color: Color = Sage) {
    Text(text.uppercase(), fontSize = 11.sp, letterSpacing = 2.sp, color = color, fontWeight = FontWeight.Bold)
}
@Composable
private fun Primary(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(onClick = onClick, enabled = enabled, shape = RoundedCornerShape(18.dp),
        modifier = modifier.fillMaxWidth().heightIn(min = 56.dp)) {
        Text(text, fontSize = 16.sp, modifier = Modifier.padding(vertical = 5.dp))
    }
}

@Composable
private fun Home(model: GameModel, guide: () -> Unit) {
    Header("LUMEN DRIFT", action = "Settings", onAction = { model.navigate(Page.SETTINGS) })
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        Eyebrow("Small puzzles. Open skies.")
        Text("Make room\nfor a little light.", fontSize = 39.sp, lineHeight = 44.sp, fontFamily = FontFamily.Serif,
            textAlign = TextAlign.Center, color = Ink, modifier = Modifier.padding(top = 12.dp))
        CelestialArt(Modifier.fillMaxWidth().height(210.dp), model.reducedMotion)
        Text("Untangle the trails. Release the lanterns.\nFind your moment of clarity.", textAlign = TextAlign.Center,
            color = Muted, fontSize = 15.sp, lineHeight = 23.sp)
        Spacer(Modifier.height(24.dp))
        val ongoing = model.session?.takeUnless { it.complete }
        Primary(if (ongoing != null) "Continue ${if (ongoing.dailyDate != null) "daily puzzle" else "puzzle ${ongoing.puzzle.level}"}  →" else "Begin puzzle ${model.unlocked}  →", model::continueGame)
        TextButton(onClick = { model.navigate(Page.ATLAS) }, modifier = Modifier.heightIn(min = 48.dp)) {
            Text("Explore the journey  ·  ${model.stars.values.count { it > 0 }} / 120", color = Ink)
        }
        Spacer(Modifier.height(8.dp))
        Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFE7EBDD), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.clickable { model.start(45, daily = true) }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("☀", color = Sage, fontSize = 28.sp, modifier = Modifier.padding(end = 16.dp))
                Column(Modifier.weight(1f)) {
                    Eyebrow("A moment for today")
                    Text(if (model.dailyDone()) "Daily drift · completed" else "Your daily drift", color = Ink, fontSize = 18.sp,
                        fontFamily = FontFamily.Serif, modifier = Modifier.padding(top = 5.dp))
                    Text("One shared sky. A new puzzle each day.", color = Muted, fontSize = 12.sp)
                }
                Text("→", color = Sage, fontSize = 22.sp)
            }
        }
        TextButton(onClick = guide, modifier = Modifier.padding(vertical = 8.dp).heightIn(min = 48.dp)) { Text("How to play", color = Muted) }
        Text("TAKE YOUR TIME. THERE’S NO CLOCK HERE.", fontSize = 9.sp, letterSpacing = 1.sp, color = Muted,
            modifier = Modifier.padding(bottom = 20.dp))
    }
}

@Composable
private fun CelestialArt(modifier: Modifier, reduced: Boolean) {
    val transition = rememberInfiniteTransition(label = "lantern float")
    val drift by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "drift")
    Canvas(modifier.semantics { contentDescription = "Original illustration of lanterns drifting through a circular night sky" }) {
        val s = min(size.width, size.height) * .86f
        val c = Offset(size.width / 2, size.height / 2)
        drawCircle(Line, s * .48f, c, style = Stroke(1.dp.toPx()))
        drawCircle(Line.copy(alpha = .55f), s * .37f, c, style = Stroke(1.dp.toPx()))
        val shift = if (reduced) 0f else (drift - .5f) * 10.dp.toPx()
        fun diamond(center: Offset, radius: Float, color: Color) {
            val p = Path().apply { moveTo(center.x,center.y-radius); lineTo(center.x+radius*.62f,center.y); lineTo(center.x,center.y+radius); lineTo(center.x-radius*.62f,center.y); close() }
            drawPath(p,color)
            drawLine(Paper.copy(alpha = .65f), center - Offset(0f,radius*.6f), center + Offset(0f,radius*.6f), 1.dp.toPx())
        }
        drawLine(Sage.copy(alpha = .22f), c+Offset(-s*.2f,s*.32f), c+Offset(-s*.2f,-s*.05f+shift), 3.dp.toPx(), StrokeCap.Round)
        drawLine(Copper.copy(alpha = .25f), c+Offset(s*.22f,s*.18f), c+Offset(s*.22f,-s*.22f-shift), 3.dp.toPx(), StrokeCap.Round)
        diamond(c+Offset(-s*.2f,-s*.13f+shift),s*.16f,Sage)
        diamond(c+Offset(s*.22f,-s*.28f-shift),s*.11f,Copper)
        diamond(c+Offset(s*.13f,s*.29f+shift),s*.08f,Color(0xFF426B87))
        listOf(Offset(-.4f,-.3f),Offset(.4f,.15f),Offset(-.05f,-.42f),Offset(-.35f,.28f)).forEach {
            val p = c + Offset(it.x*s,it.y*s)
            drawLine(Gold,p-Offset(4.dp.toPx(),0f),p+Offset(4.dp.toPx(),0f),1.5.dp.toPx())
            drawLine(Gold,p-Offset(0f,4.dp.toPx()),p+Offset(0f,4.dp.toPx()),1.5.dp.toPx())
        }
    }
}

@Composable
private fun Atlas(model: GameModel) {
    Header("THE JOURNEY", { model.navigate(Page.HOME) })
    LazyVerticalGrid(columns = GridCells.Fixed(4), contentPadding = PaddingValues(24.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(4) }) {
            Column(Modifier.padding(bottom = 10.dp)) {
                Text("A sky worth clearing.", fontFamily = FontFamily.Serif, fontSize = 30.sp)
                Text("120 small moments of discovery", color = Muted, modifier = Modifier.padding(top = 6.dp))
            }
        }
        for (chapter in 0..5) {
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(4) }) {
                Column(Modifier.padding(top = 16.dp, bottom = 8.dp)) {
                    Eyebrow("Chapter ${chapter+1}")
                    Text(Chapters[chapter], fontFamily = FontFamily.Serif, fontSize = 23.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            items((chapter*20+1..chapter*20+20).toList()) { level ->
                val open = level <= model.unlocked
                val score = model.stars[level] ?: 0
                Column(Modifier.clip(RoundedCornerShape(16.dp)).background(if (level == model.unlocked) Ink else Color.White.copy(alpha = .6f))
                    .clickable(enabled = open, onClickLabel = "Play puzzle $level") { model.start(level) }
                    .heightIn(min = 80.dp).padding(vertical = 13.dp)
                    .semantics(mergeDescendants = true) { contentDescription = "Puzzle $level, ${if (open) "$score stars" else "locked"}" },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(if (open) "$level" else "·", color = if (level == model.unlocked) Paper else if (open) Ink else Muted,
                        fontSize = 22.sp, fontFamily = FontFamily.Serif)
                    Text(if (open) "★".repeat(score) + "☆".repeat(3-score) else "Locked", fontSize = 10.sp,
                        color = if (level == model.unlocked) Gold else Copper)
                }
            }
        }
    }
}

@Composable
private fun Play(model: GameModel, guide: () -> Unit) {
    val s = model.session ?: return
    val puzzle = s.puzzle
    val haptic = LocalHapticFeedback.current
    var restart by remember { mutableStateOf(false) }
    val tap: (Int) -> Unit = { id ->
        val success = model.tap(id)
        if (model.haptics) haptic.performHapticFeedback(if (success) HapticFeedbackType.TextHandleMove else HapticFeedbackType.LongPress)
    }
    Header(if (s.dailyDate != null) "DAILY DRIFT" else "PUZZLE ${puzzle.level.toString().padStart(3,'0')}",
        { model.navigate(Page.HOME) }, "How to play", guide)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(14.dp))
        Eyebrow(if (s.dailyDate != null) "A fresh perspective" else "${Chapters[(puzzle.level-1)/20]} · ${puzzle.size} × ${puzzle.size}")
        Text(if (s.complete) "A clear sky." else "Let the lanterns go.", fontFamily = FontFamily.Serif, fontSize = 32.sp,
            modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${s.remaining} remaining", color = Muted, fontSize = 13.sp)
            Text("${s.mistakes} blocked  ·  ${s.hints} hints", color = Muted, fontSize = 13.sp)
        }
        LinearProgressIndicator(progress = { 1f - s.remaining.toFloat()/puzzle.lanterns.size }, color = Sage,
            trackColor = Line, modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 18.dp).height(3.dp))
        if (!s.complete) {
            PuzzleBoard(s, model.reducedMotion, tap)
            Text(s.message, color = if (s.blocked != null) Copper else Muted, textAlign = TextAlign.Center,
                fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.fillMaxWidth().padding(top = 18.dp).heightIn(min = 46.dp)
                    .semantics { liveRegion = LiveRegionMode.Polite })
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { restart = true }, modifier = Modifier.weight(1f).heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp)) { Text("Restart") }
                Button(onClick = model::hint, modifier = Modifier.weight(1.3f).heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp)) { Text("Reveal route") }
            }
            Text("Hints are free. Each assist affects your stars.", color = Muted, fontSize = 11.sp,
                modifier = Modifier.padding(vertical = 12.dp))
            if (model.listControls) {
                Text("LANTERN CONTROLS", fontSize = 11.sp, letterSpacing = 2.sp, color = Sage, modifier = Modifier.padding(12.dp))
                puzzle.lanterns.filter { it.id !in s.removed }.forEach { lantern ->
                    OutlinedButton(onClick = { tap(lantern.id) }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
                        Text("${lantern.id+1} · row ${lantern.cells.first().y+1}, column ${lantern.cells.first().x+1} · ${lantern.heading.label}${if (s.hint == lantern.id) " · clear route" else ""}")
                    }
                }
            }
        } else {
            CelestialArt(Modifier.fillMaxWidth().height(190.dp), model.reducedMotion)
            Text("★".repeat(Rules.stars(s.mistakes,s.hints)) + "☆".repeat(3-Rules.stars(s.mistakes,s.hints)),
                color = Copper, fontSize = 36.sp, letterSpacing = 8.sp,
                modifier = Modifier.semantics { contentDescription = "${Rules.stars(s.mistakes,s.hints)} out of 3 stars" })
            Text(if (s.dailyDate != null) "Today’s sky is yours." else if (puzzle.level == 120) "Every lantern has found its way home." else "A little patience. A little perspective.",
                textAlign = TextAlign.Center, color = Muted, modifier = Modifier.padding(18.dp))
            Primary(if (s.dailyDate != null || puzzle.level == 120) "Back to the garden" else "Next puzzle  →", {
                if (s.dailyDate != null || puzzle.level == 120) model.navigate(Page.HOME) else model.start(puzzle.level+1)
            }, Modifier.padding(top = 10.dp))
            TextButton(onClick = model::restart, modifier = Modifier.heightIn(min = 48.dp)) { Text("Try for a perfect sky") }
        }
        Spacer(Modifier.height(22.dp))
    }
    if (restart) AlertDialog(onDismissRequest = { restart = false }, title = { Text("Reset this sky?") },
        text = { Text("This puzzle’s moves and assists will be reset. Your best stars are kept.") },
        confirmButton = { TextButton(onClick = { model.restart(); restart = false }) { Text("Restart puzzle") } },
        dismissButton = { TextButton(onClick = { restart = false }) { Text("Keep playing") } })
}

@Composable
private fun PuzzleBoard(s: Session, reduced: Boolean, tap: (Int) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(24.dp)).background(Color(0xFFEBEDE3))
        .border(1.dp, Line, RoundedCornerShape(24.dp))) {
        val unit = maxWidth / (s.puzzle.size + 1)
        Canvas(Modifier.fillMaxSize()) {
            val step = size.width / (s.puzzle.size+1)
            for (y in 0 until s.puzzle.size) for (x in 0 until s.puzzle.size) {
                drawCircle(Ink.copy(alpha = .14f), 1.3.dp.toPx(), Offset((x+1)*step,(y+1)*step))
            }
        }
        s.puzzle.lanterns.forEach { lantern ->
            key(s.puzzle, lantern.id) {
                val removed = lantern.id in s.removed
                val release by animateFloatAsState(if (removed) 1f else 0f, tween(if (reduced) 0 else 380), label = "release")
                var shake by remember { mutableStateOf(false) }
                LaunchedEffect(s.event) {
                    if (s.blocked == lantern.id && !reduced) { shake = true; delay(160); shake = false }
                }
                val nudge by animateFloatAsState(if (shake) 1f else 0f, tween(80), label = "blocked")
                val color by animateColorAsState(if (s.blocked == lantern.id) Copper else if (s.hint == lantern.id) Ink else TrailColors[lantern.id % TrailColors.size], label = "trail color")
                if (release < .99f) Canvas(Modifier.fillMaxSize().alpha(1f-release)) {
                    val step = size.width / (s.puzzle.size+1)
                    val movement = Offset(lantern.heading.dx * (release * step * 3 + nudge * 5.dp.toPx()), lantern.heading.dy * (release * step * 3 + nudge * 5.dp.toPx()))
                    fun point(c: Cell) = Offset((c.x+1)*step,(c.y+1)*step)+movement
                    val tip = point(lantern.cells.first())
                    if (s.hint == lantern.id) {
                        drawCircle(Gold.copy(alpha = .35f),step*.48f,tip)
                        val end = tip + Offset(lantern.heading.dx*size.width,lantern.heading.dy*size.height)
                        drawLine(Gold,tip,end,2.dp.toPx(),StrokeCap.Round,
                            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(),6.dp.toPx())))
                    }
                    val path = Path().apply {
                        lantern.cells.reversed().forEachIndexed { index,c -> val p=point(c); if(index==0) moveTo(p.x,p.y) else lineTo(p.x,p.y) }
                    }
                    drawPath(path,color,style = Stroke(5.dp.toPx(), cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                    val forward = Offset(lantern.heading.dx.toFloat(),lantern.heading.dy.toFloat())
                    val side = Offset(-forward.y,forward.x)
                    val arrow = Path().apply {
                        val a=tip+forward*step*.24f; val b=tip-forward*step*.12f+side*step*.16f; val c=tip-forward*step*.12f-side*step*.16f
                        moveTo(a.x,a.y);lineTo(b.x,b.y);lineTo(c.x,c.y);close()
                    }
                    drawPath(arrow,color)
                    drawCircle(Paper,2.dp.toPx(),point(lantern.cells.last()))
                }
                // Every occupied cell is tappable; descriptions expose shape-independent controls to TalkBack.
                if (!removed) lantern.cells.forEachIndexed { index, cell ->
                    Box(Modifier.absoluteOffset(unit*(cell.x+.5f), unit*(cell.y+.5f)).size(unit)
                        .semantics {
                            contentDescription = "Lantern ${lantern.id+1}, ${lantern.heading.label}, row ${cell.y+1}, column ${cell.x+1}${if(s.hint==lantern.id) ", clear route" else ""}"
                            role = Role.Button
                            if (index > 0) hideFromAccessibility()
                        }
                        .clickable(onClickLabel = "Release lantern ${lantern.id+1}") { tap(lantern.id) })
                }
            }
        }
    }
}

@Composable
private fun Settings(model: GameModel, privacy: PrivacyAds, privacyText: () -> Unit, reset: () -> Unit) {
    Header("YOUR QUIET CORNER", { model.navigate(Page.HOME) })
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Just the way\nyou like it.", fontFamily = FontFamily.Serif, fontSize = 36.sp, lineHeight = 42.sp)
        Spacer(Modifier.height(12.dp))
        Eyebrow("Comfort")
        Preference("Gentle haptics", "A little feedback with every launch", model.haptics, model::updateHaptics)
        Preference("Reduced motion", "Instant releases and a still sky", model.reducedMotion, model::updateReducedMotion)
        Preference("List controls", "Large text buttons below each board", model.listControls, model::updateListControls)
        HorizontalDivider(color = Line, modifier = Modifier.padding(vertical = 8.dp))
        Eyebrow("Privacy & data")
        OutlinedButton(onClick = privacyText, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Read privacy notice") }
        OutlinedButton(onClick = privacy::privacyOptions, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
            Text(if (privacy.privacyRequired) "Privacy choices" else "Check privacy options")
        }
        Text(privacy.status, color = Muted, fontSize = 12.sp, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
        TextButton(onClick = reset, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Delete local progress", color = Copper) }
        HorizontalDivider(color = Line)
        Text("LUMEN DRIFT", fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold, color = Sage)
        Text("Original artwork. Independent code.\nVersion 1.0.0 · Development build · Test ads only", color = Muted, fontSize = 12.sp, lineHeight = 20.sp)
    }
}
@Composable
private fun Preference(title: String, subtitle: String, checked: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 76.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = change, modifier = Modifier.semantics { contentDescription = title })
    }
}
