package com.lumendrift.game

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.ads.*
import com.google.android.ump.*

/** Consent first: no AdView, ad request, or explicit MobileAds.initialize call until UMP allows ads. */
class PrivacyAds(private val activity: Activity) {
    private val consent = UserMessagingPlatform.getConsentInformation(activity)
    var adsReady by mutableStateOf(false); private set
    var privacyRequired by mutableStateOf(false); private set
    var status by mutableStateOf("Checking privacy choices…"); private set
    private var initialized = false
    fun requestConsent() {
        status = "Checking privacy choices…"
        consent.requestConsentInfoUpdate(activity, ConsentRequestParameters.Builder().build(), {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { error ->
                status = if (error == null) "Privacy choices are up to date." else "Consent unavailable. The game works without ads."
                update()
            }
        }, {
            status = "Privacy service unavailable. The game works without ads."
            update()
        })
    }
    fun privacyOptions() {
        if (!privacyRequired) { requestConsent(); return }
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { error ->
            status = if (error == null) "Privacy choices updated." else "Could not open privacy choices. Please try again."
            update()
        }
    }
    private fun update() {
        privacyRequired = consent.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
        if (!consent.canRequestAds()) { adsReady = false; return }
        if (initialized) { adsReady = true; return }
        initialized = true
        MobileAds.initialize(activity) {
            activity.runOnUiThread { adsReady = consent.canRequestAds() }
        }
    }
}

@Composable
fun TestBanner(privacy: PrivacyAds) {
    if (!privacy.adsReady) return
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    BoxWithConstraints(Modifier.fillMaxWidth()) {
    val width = (maxWidth.value.toInt() - 32).coerceAtLeast(200).coerceAtMost(600)
    val view = remember(context, width) {
        AdView(context).apply {
            adUnitId = "ca-app-pub-3940256099942544/6300978111" // Official Google test banner.
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, width))
            loadAd(AdRequest.Builder().build())
        }
    }
    DisposableEffect(view, owner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> view.pause()
                Lifecycle.Event.ON_RESUME -> view.resume()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); view.destroy() }
    }
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("ADVERTISEMENT · TEST", fontSize = 9.sp, color = Muted)
        AndroidView(factory = { view }, modifier = Modifier.width(width.dp).height(view.adSize?.getHeightInPixels(context)?.let {
            with(context.resources.displayMetrics) { (it / density).dp }
        } ?: 60.dp))
    }
}
}
