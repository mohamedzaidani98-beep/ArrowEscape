package com.lumendrift.game

import kotlin.random.Random

/** Original rules implementation. Coordinates are column, row; a head is cells.first(). */
data class Cell(val x: Int, val y: Int) {
    operator fun plus(direction: Heading) = Cell(x + direction.dx, y + direction.dy)
}
enum class Heading(val dx: Int, val dy: Int, val label: String) {
    NORTH(0, -1, "north"), EAST(1, 0, "east"), SOUTH(0, 1, "south"), WEST(-1, 0, "west");
    fun opposite() = entries[(ordinal + 2) % 4]
}
data class Lantern(val id: Int, val cells: List<Cell>, val heading: Heading)
data class Puzzle(val level: Int, val size: Int, val lanterns: List<Lantern>) {
    fun inside(cell: Cell) = cell.x in 0 until size && cell.y in 0 until size
}
sealed interface Launch {
    data class Released(val id: Int) : Launch
    data class Blocked(val blocker: Int) : Launch
    data object Ignored : Launch
}
object Rules {
    fun launch(puzzle: Puzzle, removed: Set<Int>, id: Int): Launch {
        val lantern = puzzle.lanterns.find { it.id == id && it.id !in removed } ?: return Launch.Ignored
        val occupied = puzzle.lanterns.filter { it.id != id && it.id !in removed }
            .flatMap { other -> other.cells.map { it to other.id } }.toMap()
        var cell = lantern.cells.first() + lantern.heading
        while (puzzle.inside(cell)) {
            occupied[cell]?.let { return Launch.Blocked(it) }
            cell += lantern.heading
        }
        return Launch.Released(id)
    }
    fun available(puzzle: Puzzle, removed: Set<Int>) = puzzle.lanterns.filter {
        launch(puzzle, removed, it.id) is Launch.Released
    }.map { it.id }
    fun stars(mistakes: Int, hints: Int): Int = (3 - (mistakes + hints).coerceAtMost(2)).coerceIn(1, 3)
}

/** Build trails whose exits are clear of earlier trails. Reverse insertion order is a witness
 * solution. Removing trails only opens routes, so every legal choice preserves solvability. */
object PuzzleFactory {
    const val LEVEL_COUNT = 120
    private const val REVISION = 1
    fun create(level: Int, seed: Long = level.toLong() * 7919L): Puzzle {
        require(level in 1..LEVEL_COUNT)
        val random = Random(seed xor (REVISION.toLong() shl 48))
        val size = when { level <= 8 -> 5; level <= 35 -> 6; else -> 7 }
        val desired = (5 + level / 4).coerceAtMost(23)
        val occupied = mutableSetOf<Cell>()
        val pieces = mutableListOf<Lantern>()
        repeat(1800) {
            if (pieces.size >= desired) return@repeat
            val head = Cell(random.nextInt(size), random.nextInt(size))
            if (head in occupied) return@repeat
            val heading = Heading.entries[random.nextInt(4)]
            val ray = mutableSetOf<Cell>()
            var cursor = head + heading
            while (cursor.x in 0 until size && cursor.y in 0 until size) {
                ray += cursor
                cursor += heading
            }
            if (ray.any { it in occupied }) return@repeat
            val cells = mutableListOf(head)
            val length = if (level <= 3) 1 else random.nextInt(1, if (level < 25) 4 else 6)
            var previous = heading.opposite()
            repeat(length) {
                val choices = if (cells.size == 1) listOf(previous) else
                    Heading.entries.shuffled(random).sortedBy { if (it == previous) 0 else 1 }
                val next = choices.firstOrNull { dir ->
                    val point = cells.last() + dir
                    point.x in 0 until size && point.y in 0 until size &&
                        point !in occupied && point !in cells && point !in ray
                }
                if (next != null) { cells += cells.last() + next; previous = next }
            }
            // A tail is always present, making the direction readable without color.
            if (cells.size < 2) return@repeat
            pieces += Lantern(pieces.size, cells.toList(), heading)
            occupied += cells
        }
        check(pieces.isNotEmpty())
        return Puzzle(level, size, pieces.toList())
    }
}
