package com.lumendrift.game

import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SessionTest {
    @Test fun movesHintsAndPreferencesSurviveActivityRecreation() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            var released = -1
            scenario.onActivity { activity ->
                val model = ViewModelProvider(activity)[GameModel::class.java]
                model.start(1)
                val session = model.session!!
                released = Rules.available(session.puzzle, session.removed).first()
                assertTrue(model.tap(released))
                model.hint()
                model.updateReducedMotion(true)
                val restored = GameModel(activity.application)
                assertTrue(released in restored.session!!.removed)
                assertEquals(1, restored.session!!.hints)
                assertTrue(restored.reducedMotion)
            }
            scenario.recreate()
            scenario.onActivity { activity ->
                val model = ViewModelProvider(activity)[GameModel::class.java]
                assertTrue(released in model.session!!.removed)
                assertEquals(1, model.session!!.hints)
                assertTrue(model.reducedMotion)
                model.restart()
                assertTrue(model.session!!.removed.isEmpty())
                assertEquals(0, model.session!!.hints)
            }
        }
    }
    @Test fun dailyCompletionDoesNotUnlockCampaignAndResetDeletesProgress() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                val model = ViewModelProvider(activity)[GameModel::class.java]
                model.eraseProgress()
                model.start(45, daily = true)
                val p = model.session!!.puzzle
                p.lanterns.reversed().forEach { assertTrue(model.tap(it.id)) }
                assertTrue(model.dailyDone())
                assertEquals(1,model.unlocked)
                model.start(1)
                model.hint()
                model.session!!.puzzle.lanterns.reversed().forEach { model.tap(it.id) }
                assertEquals(2, model.stars[1])
                assertEquals(2, model.unlocked)
                model.eraseProgress()
                assertFalse(model.dailyDone())
                assertEquals(0,model.stars[1])
                assertNull(model.session)
            }
        }
    }
}
