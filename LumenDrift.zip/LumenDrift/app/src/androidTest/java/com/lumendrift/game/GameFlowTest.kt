package com.lumendrift.game

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class GameFlowTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    @Test fun completeFirstPuzzleUsingAccessibleControls() {
        compose.onNodeWithText("Settings").performClick()
        compose.onNodeWithContentDescription("List controls").performClick()
        compose.activityRule.scenario.onActivity { activity ->
            val model = androidx.lifecycle.ViewModelProvider(activity)[GameModel::class.java]
            model.start(1)
        }
        val puzzle = PuzzleFactory.create(1)
        puzzle.lanterns.reversed().forEach { lantern ->
            compose.onNodeWithText("${lantern.id+1} · row ${lantern.cells.first().y+1}, column ${lantern.cells.first().x+1} · ${lantern.heading.label}")
                .performScrollTo().performClick()
        }
        compose.onNodeWithText("A clear sky.").assertExists()
        compose.onNodeWithText("Next puzzle  →").performScrollTo().performClick()
        compose.onNodeWithText("PUZZLE 002").assertExists()
    }
}
