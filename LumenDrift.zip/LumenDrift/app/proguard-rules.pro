# Google Mobile Ads and UMP publish their own consumer rules.
# No broad keep rules or debug logging are required.
