# Lumen Drift

An original English-language Android puzzle game written in Kotlin and Jetpack Compose.
Release lantern-shaped trails into an open sky, one clear route at a time. No timer, no lives,
no paid hints. 120 seeded campaign puzzles, a local daily puzzle, best-star tracking, resume,
large list controls, haptics, and reduced motion are included.

## Open and run

Open this directory in Android Studio with support for Android Gradle Plugin 8.13.2 or newer. Select JDK 21
for Gradle. Install Android SDK Platform 36 and Build Tools 35.0.0. Let Studio create
`local.properties` for your SDK. The checked-in Gradle wrapper pins Gradle 8.13.

```sh
./gradlew :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
./gradlew :app:installDebug
# With an emulator or physical Android device connected:
./gradlew :app:connectedDebugAndroidTest
# Unsigned, minified release bundle for publisher signing:
./gradlew :app:bundleRelease
```

Minimum Android: 7.0 (API 24). Target/compile: API 36. No server or developer credentials
are required. Gameplay works offline; Google ads and consent services require connectivity.
Google's official **sample AdMob application ID and test banner unit ID** are deliberately
used in every build variant. There are no interstitials or rewarded advertisements.

## Play

Tap any segment of a trail. Its tip travels straight north, east, south, or west. If another
trail occupies a cell ahead of the tip, the lantern stays put; remove the obstruction first.
The curved body dissolves as the lantern leaves. Clear every lantern to finish. There is no
failure lockout. Three stars require no blocked launches and no hints; one assist gives two
stars, two or more gives one. Replays keep your best rating. Reveal route is always free.
The daily puzzle uses the device's local date, has its own seed, and does not unlock campaign
levels. Daily completion is local; there is no online leaderboard or trusted clock.

Use Android Back to return home. The current board is saved after every move, hint, and
restart. You can resume it after rotation or process restart. Starting a different puzzle
replaces the current board; earned campaign stars are retained.

## Project map

- `Puzzle.kt`: platform-independent model, collision rules, seeded generator, scoring.
- `GameModel.kt`: observable session state and bounded, versioned private local persistence.
- `MainActivity.kt`: Compose screens, original vector/Canvas art, accessible controls, animation.
- `Ads.kt`: UMP consent flow, consent-gated Mobile Ads initialization, lifecycle-managed test banner.
- `app/src/test`: rule fixtures and solvability across 2,400 seeded boards; Robolectric
  persistence tests and Compose touch/control/level-completion tests.
- `app/src/androidTest`: Compose gameplay integration test.
- `docs/REFERENCE_STUDY.md`: behavior study and independent implementation boundaries.
- `docs/SECURITY.md`: security controls and outstanding OWASP mapping.
- `docs/RELEASE.md`: publisher-specific steps required before a commercial release.
- `docs/CLOUD_SETUP.md`: tested cloud installation, activation, and emulator instructions.

No original game's code, assets, fonts, branding, or level data is included. All illustration
and icon artwork is drawn with this project's original geometry. Android system fonts are
used. This project is not affiliated with the reference game's author.

See `docs/VALIDATION.md` for the checks actually performed in the delivery environment.
