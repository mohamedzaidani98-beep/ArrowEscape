# Third-party notices

Application Kotlin source and original vector/Canvas geometry are offered under the root MIT
license. No source or assets from Arrow Escape are distributed in this project.

This app uses Android/AndroidX (including Jetpack Compose and Lifecycle), Kotlin, Google
Mobile Ads SDK, and Google User Messaging Platform. Their own licenses and service terms
continue to apply. AndroidX/Kotlin components are generally Apache 2.0; Google SDKs are
subject to their SDK terms and bundled notices. Gradle's generated wrapper includes its
Apache 2.0 license headers. JUnit is used for development tests under EPL 1.0.

Review dependency POMs and packaged META-INF notices for the exact resolved artifacts before
release. The application MIT license does not relicense third-party dependencies or grant
rights to Google's services, trademarks, or advertising inventory.
